from .Funciones import detec_outliers 
from .Funciones import cal_random_probability
from .Funciones import durbin_watson
from .Funciones import calculate_dL
from .Funciones import calculate_dU
from .Funciones import train_neural_network
from .Funciones import train_svr_model 